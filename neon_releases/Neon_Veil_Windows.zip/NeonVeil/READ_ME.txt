NEON VEIL — KASUMI PASSAGE | GODOT 4.5 | WINDOWS x64

Extract this entire ZIP. Run NeonVeil.exe. No Godot or Blender installation needed.
Keep every file beside the executable in place. Game data is embedded in the EXE.
Use a modern Windows x64 PC with Vulkan-capable graphics and current GPU drivers.

WASD: move | Mouse: look | Shift: sprint | Ctrl: crouch
E: use terminal while looking at it | Esc: pause / resume

Copy the cipher at the left terminal. Reroute the relay on the right.
Crouch beneath its awning until the patrol clears. Open the transit gate,
then deliver the archive at the private uplink. Follow the objective and diamond.
Balanced visuals reduce expensive fog/reflections. No save system; replay from title.

The Windows export contains the actual game and runtime. Functional checks and
Forward+ rendering were performed on Linux, including testing the exported embedded
game data. Native Windows execution and Windows GPU performance were not tested.

Original environment models, textures, music and sounds. DejaVu fonts and Godot
engine/dependency license notices are included in LICENSES.
