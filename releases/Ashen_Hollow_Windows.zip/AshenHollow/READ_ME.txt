ASHEN HOLLOW — WINDOWS x86-64

Extract this entire ZIP, then run AshenHollow.exe.
The game data is embedded in the executable. No Godot installation is required.
The default renderer is Forward+.
For an older GPU, try Play_Compatibility.bat (OpenGL, reduced rendering features).

CONTROLS
WASD move | Mouse camera | Shift sprint | Space jump | Left Ctrl dodge
Left mouse: light combo | Q: heavy | Hold right mouse: frontal block
Tab: lock/unlock | Mouse wheel while locked: change target | E: inspect shrine
Esc: pause/resume

QUEST
Follow the forest road. Defeat the three village bandits. Continue north to
the blue-lit shrine and press E. Defeat the Hollow Warden in the ruined court.
Reading the shrine restores 35 health and all stamina. Death offers a full restart.

VERIFICATION
Godot 4.6.3. 110 source-project automated checks passed. The exported embedded
game data passed 51 integration checks using the Linux Godot engine.
Forward+ screenshots were inspected on Linux. Native Windows execution has
not been tested in the build environment.

Fonts: DejaVu; see LICENSES. Engine: Godot, MIT; full engine notices included.
