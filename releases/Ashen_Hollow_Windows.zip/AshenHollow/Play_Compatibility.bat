@echo off
cd /d "%~dp0"
start "Ashen Hollow" "%~dp0AshenHollow.exe" --rendering-method gl_compatibility
